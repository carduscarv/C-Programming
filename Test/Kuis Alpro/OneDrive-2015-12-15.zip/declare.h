#include <stdio.h>
#include <string.h>

// deklarasi fungsi
int cek_genap (char str[]);
int cek_ganjil (char str[]);
// deklarasi prosedur
void print_pola1 (int n, char str[n][64]);
void print_pola2 (int n, char str[n][64]);


//JANJI
/* Saya Muhammad Naufal Fazanadi tidak melakukan kecurangan seperti yang telah dispesifikasikan
pada mata kuliah Algoritma dan Pemograman 1 dalam mengerjakan Kuis 3,
jika saya melakukan kecurangan maka Allah/Tuhan adalah saksi saya, 
dan saya bersedia menerima hukumanNya. Aamiin. */
